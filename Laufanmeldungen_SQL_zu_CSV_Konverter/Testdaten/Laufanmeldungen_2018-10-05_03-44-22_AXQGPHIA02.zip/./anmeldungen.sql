-- ---------------------------------------------------------
-- Backup with BackWPup ver.: 3.6.0
-- http://backwpup.com/
-- Blog Name: Lentföhrden läuft
-- Blog URL: https://www.xn--lentfhrden-luft-clb21a.de/
-- Blog ABSPATH: /hp/cn/ac/en/www/_lentfoehrden_laeuft/
-- Blog Charset: UTF-8
-- Table Prefix: wp_
-- Database Name: db212304x2747338
-- Backup on: 2018-10-05 03:44.22
-- ---------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='SYSTEM' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


--
-- Table structure for `wp_laufanmeldungen`
--

DROP TABLE IF EXISTS `wp_laufanmeldungen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8mb4' */;
CREATE TABLE `wp_laufanmeldungen` (
  `startnummer` int(10) unsigned NOT NULL DEFAULT '0',
  `datum` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `form_id` int(10) unsigned NOT NULL,
  `vorname` char(50) NOT NULL DEFAULT '',
  `nachname` char(50) NOT NULL DEFAULT '',
  `email` char(50) NOT NULL DEFAULT '',
  `strecke` char(50) NOT NULL DEFAULT '',
  `verein` char(50) NOT NULL DEFAULT '',
  `bemerkung` char(250) NOT NULL DEFAULT '',
  `bestaetigung1` char(50) NOT NULL DEFAULT '',
  `bestaetigung2` char(50) NOT NULL DEFAULT '',
  `bestaetigung3` char(50) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `wp_laufanmeldungen`
--

LOCK TABLES `wp_laufanmeldungen` WRITE;
/*!40000 ALTER TABLE `wp_laufanmeldungen` DISABLE KEYS */;
INSERT INTO `wp_laufanmeldungen` (`startnummer`, `datum`, `form_id`, `vorname`, `nachname`, `email`, `strecke`, `verein`, `bemerkung`, `bestaetigung1`, `bestaetigung2`, `bestaetigung3`) VALUES 
(17, 0x323031382d30372d32322031373a35373a3538, 11, 'Ronny', 'Sikora', 'ronnysikora@gmx.de', '6,6 km', '', '', '1', '1', '1'),
(18, 0x323031382d30372d32322031383a31313a3436, 11, 'Stefan', 'Kirschke', 'stefan.kirschke@gmx.de', '3,3 km', '', '', '1', '1', '1'),
(19, 0x323031382d30372d32322032303a32393a3431, 11, 'Janina', 'Osswald', 'janina1983.1@web.de', '6,6 km', '', '', '1', '1', '1'),
(20, 0x323031382d30372d32332030383a30363a3139, 11, 'Peter', 'Tittelbach', 'familie.tittelbach@hotmail.de', '3,3 km', '', '', '1', '1', '1'),
(21, 0x323031382d30372d32332030383a30373a3239, 11, 'Lilly', 'Tittelbach', 'familie.tittelbach@hotmail.de', '500 m (Kinderlauf)', '', '', '1', '1', '1'),
(22, 0x323031382d30372d32332030383a30383a3134, 11, 'Janine', 'Casarin-Tittelbach', 'familie.tittelbach@hotmail.de', '3,3 km', '', '', '1', '1', '1'),
(23, 0x323031382d30372d32332032303a34373a3230, 11, 'Christin', 'Wucherpfennig', 'christin-wucherpfennig@gmx.de', '6,6 km', '', '', '1', '1', '1'),
(23, 0x323031382d30372d32332032303a34383a3438, 11, 'Lene', 'Wucherpfennig', 'christin-wucherpfennig@mx.de', '500 m (Kinderlauf)', '', '', '1', '1', '1'),
(25, 0x323031382d30372d32342031343a30323a3235, 11, 'Dieter', 'Abraham', 'adr@dieter-abraham.de', '3,3 km', '', '', '1', '1', '1'),
(26, 0x323031382d30372d32352031333a34343a3538, 11, 'Oliver', 'Thiess', 'OThiess@gmx.de', '3,3 km', '', '', '1', '1', '1'),
(27, 0x323031382d30372d32352031353a31303a3232, 11, 'Sarah', 'Thilo', 'sarah.thilo@gmx.de', '10 km', '', '', '1', '1', '1'),
(28, 0x323031382d30372d32352031353a31303a3438, 11, 'Maik', 'Britz', 'maikbritz@yahoo.de', '10 km', '', '', '1', '1', '1'),
(29, 0x323031382d30372d32372031323a30373a3536, 11, 'Anja', 'Blasberg', 'anja.blasberg@googlemail.com', '3,3 km', '', 'Gruppe 3 Personen', '1', '1', '1'),
(30, 0x323031382d30372d32372031373a32313a3339, 11, 'Claudia', 'Jochum', 'skorpionlady65@online.de', '6,6 km', '&quot;Die Fußfee&quot;', 'Ich bin Nordic-Walkerin', '1', '1', '1'),
(31, 0x323031382d30372d32372031393a35333a3330, 11, 'Marianne', 'Hähn', 'm.haehn@gmx.de', '6,6 km', 'Die Kaki Walker', '', '1', '1', '1'),
(32, 0x323031382d30372d32392031323a32353a3331, 11, 'Paula', 'Enseleit', 'paula_enseleit@web.de', '6,6 km', '', '', '1', '1', '1'),
(33, 0x323031382d30372d32392031323a32373a3235, 11, 'Yvonne', 'Strietzel', 'ys@danemu.de', '3,3 km', '', 'Gruppe', '1', '1', '1'),
(34, 0x323031382d30372d32392032323a33353a3538, 11, 'Katrin', 'Glüsing', 'katrin.gluesing@gmx.de', '3,3 km', '', 'Gruppennummer 33', '1', '1', '1'),
(35, 0x323031382d30382d30312031343a32303a3232, 11, 'Michael', 'Heiden', 'Michael_Heiden@gmx.de', '10 km', '', '', '1', '1', '1'),
(36, 0x323031382d30382d30312032313a32373a3433, 11, 'Ute', 'Austelat', 'umeier67@web.de', '3,3 km', '', '', '1', '1', '1'),
(37, 0x323031382d30382d30312032313a32383a3137, 11, 'Kai', 'Austelat', 'umeier67@web.de', '3,3 km', '', '', '1', '1', '1'),
(38, 0x323031382d30382d30382031373a32363a3332, 11, 'Bernhard', 'Gottwald', 'gottwald-bernhard@t-online.de', '3,3 km', 'Nein', 'Mein erster offizieller Lauf', '1', '1', '1'),
(39, 0x323031382d30382d30382031373a32373a3538, 11, 'Mika-Leon', 'Biethan', 'gottwald-bernhard@t-online.de', '3,3 km', 'Nein', '', '1', '1', '1'),
(40, 0x323031382d30382d31332031343a34313a3137, 11, 'Andreas', 'Japing', 'Andreas.japing@web.de', '3,3 km', '', '', '1', '1', '1'),
(41, 0x323031382d30382d31332032313a33353a3438, 11, 'Lea', 'Haase', 'christina@daehling.de', '820 m (Kinderlauf)', '', '', '1', '1', '1'),
(42, 0x323031382d30382d31332032313a33363a3336, 11, 'Lars', 'Haase', 'christina@daehling.de', '820 m (Kinderlauf)', '', '', '1', '1', '1'),
(43, 0x323031382d30382d31332032313a33383a3132, 11, 'Tini', 'Haase', 'christina@daehling.de', '3,3 km', '', '', '1', '1', '1'),
(44, 0x323031382d30382d31332032333a32353a3530, 11, 'Daniel', 'Zwiener', 'danielzwiener@hotmail.com', '3,3 km', '', 'Gruppe/ 10 Personen', '1', '1', '1'),
(45, 0x323031382d30382d31352031333a34323a3239, 11, 'Sabrina', 'Feldmann', 'sabrina.feldmann72@gmail.com', '6,6 km', 'TSV Bargteheide Tri', '', '1', '1', '1'),
(45, 0x323031382d30382d31352031333a34333a3432, 11, 'Lars', 'Feldmann', 'sabrina.feldmann72@gmail.com', '6,6 km', 'TSV Bargteheide Tri', '', '1', '1', '1'),
(47, 0x323031382d30382d31352031333a34343a3433, 11, 'Julia', 'Eckmann', 'sabrina.feldmann72@gmail.com', '3,3 km', 'TSV Bargteheide Tri', '', '1', '1', '1'),
(48, 0x323031382d30382d31382031353a31373a3230, 11, 'Pauline', 'Horst', 'de@horst-einbaukuechen.de', '820 m (Kinderlauf)', '', '', '1', '1', '1'),
(49, 0x323031382d30382d32302031343a34303a3539, 11, 'Doris', 'Lewerenz', 'DorisLewerenz@aol.com', '6,6 km', 'Die Kaki-Walker', 'Gruppe 2Personen', '1', '1', '1'),
(50, 0x323031382d30382d32302031363a33343a3236, 11, 'Ute', 'Austelat', 'umeier67@web.de', '3,3 km', '', '', '1', '1', '1'),
(51, 0x323031382d30382d32302031363a33353a3437, 11, 'Kai', 'Austelat', 'umeier67@web.de', '3,3 km', '', '', '1', '1', '1'),
(52, 0x323031382d30382d32302032313a32363a3137, 11, 'Janina', 'Andresen', 'janina1983.1@web.de', '6,6 km', '', '', '1', '1', '1'),
(53, 0x323031382d30382d32312030383a30383a3030, 11, 'Harry', 'Schumacher', 'harry-hitz@web.de', '6,6 km', 'Die Kaki-Walker', '', '1', '1', '1'),
(54, 0x323031382d30382d32312031353a31373a3432, 11, 'Adam', 'Chrabkowski', 'chrabkowski@gmx.de', '10 km', '', '', '1', '1', '1'),
(55, 0x323031382d30382d32352031373a32373a3238, 11, 'Svenja', 'Schneider', 'svenjaschneider@web.de', '3,3 km', '', 'Gruppe\r\n2 Personen', '1', '1', '1'),
(56, 0x323031382d30382d32352031383a31303a3438, 11, 'iris', 'kasten', 'iriskasten21@aol.com', '820 m (Kinderlauf)', '', 'wir laufen zu dritt als Familie.Mein Mann 10km, ich 6,6km Walken, mein Sohn weiss noch nicht wieviel.\r\n', '1', '1', '1'),
(57, 0x323031382d30382d33312031393a31333a3039, 11, 'Daniela', 'Gätgens', 'D.Gaetgens@web.de', '6,6 km', 'TSV Lentföhrden', '', '1', '1', '1'),
(58, 0x323031382d30382d33312032313a32343a3533, 11, 'Nilofar', 'Zirkel', 'Nilofarzirkel@t-online.de', '10 km', '', '', '1', '1', '1'),
(59, 0x323031382d30382d33312032313a32363a3131, 11, 'Stefan', 'Zirkel', 'Nilofarzirkel@t-online.de', '10 km', '', '', '1', '1', '1'),
(60, 0x323031382d30382d33312032313a32373a3130, 11, 'Michelle', 'Zirkel', 'Nilofarzirkel@t-online.de', '820 m (Kinderlauf)', '', '', '1', '1', '1'),
(61, 0x323031382d30392d30332031303a34363a3536, 11, 'Maren', 'Bahde', 'm.bahde@abw-wirtschaftsberatung.de', '10 km', '', '', '1', '1', '1'),
(62, 0x323031382d30392d30332031303a34383a3234, 11, 'Jörg', 'Pingel', 'sup-pingel@versanet.de', '10 km', '', '', '1', '1', '1'),
(63, 0x323031382d30392d30342030373a34363a3330, 11, 'Kerstin', 'Bergmann', 'kerstin@die-bergmanns.net', '6,6 km', '', 'Gruppe mit 3 Personen', '1', '1', '1'),
(64, 0x323031382d30392d30342031333a32393a3437, 11, 'Nicola', 'Van der Togt', 'n.vandertogt@gmail.com', '3,3 km', '', 'Familie 2Erwachsene 2 Kinder', '1', '1', '1'),
(65, 0x323031382d30392d30342032313a35373a3439, 11, 'Clara', 'Gosling', 'manjagosling@hotmail.de', '3,3 km', '', '', '1', '1', '1'),
(66, 0x323031382d30392d30342032313a35393a3439, 11, 'Manja', 'Gosling', 'manjagosling@hotmail.de', '6,6 km', '', '', '1', '1', '1'),
(67, 0x323031382d30392d30352030393a30343a3133, 11, 'Felix', 'Feil', 'feil.felix@gmx.de', '10 km', '', '', '1', '1', '1'),
(68, 0x323031382d30392d30362031343a32323a3030, 11, 'Greta', 'Kahlke', 'gretakahlke@web.de', '3,3 km', '', '', '1', '1', '1'),
(69, 0x323031382d30392d30362031373a30383a3435, 11, 'Dirk', 'Sauerland', 'dirk.sauerland@gmx.de', '3,3 km', '', '', '1', '1', '1'),
(70, 0x323031382d30392d30362031373a30393a3437, 11, 'Steffi', 'Sauerland', 'stefanie.sauerland@gmx.de', '3,3 km', '', '', '1', '1', '1'),
(71, 0x323031382d30392d30382031353a31343a3135, 11, '', '', 'jens_gohlke@yahoo.de', '6,6 km', 'FF Lentföhrden', '8 Teilnehmer', '1', '1', '1'),
(72, 0x323031382d30392d30392031363a34363a3136, 11, 'Sonja', 'Öfler', 'sonja.oefler@yahoo.de', '6,6 km', '', '', '1', '1', '1'),
(72, 0x323031382d30392d30392031363a34373a3137, 11, 'Klaus', 'Öfler', 'klaus.oefler@freenet.de', '6,6 km', '', '', '1', '1', '1'),
(74, 0x323031382d30392d30392031363a34383a3439, 11, 'Luke', 'Öfler', 'sonja.oefler@yahoo.de', '6,6 km', '', '', '1', '1', '1'),
(74, 0x323031382d30392d30392031363a35333a3338, 11, 'Klaus', 'Öfler', 'klaus.oefler@freenet.de', '6,6 km', '', '', '1', '1', '1'),
(76, 0x323031382d30392d30392031363a35373a3533, 11, 'klaus', 'Öfler', 'klaus.oefler@freenet.de', '6,6 km', '', '', '1', '1', '1'),
(77, 0x323031382d30392d30392032303a34393a3339, 11, 'Maren', 'Ring', 'maren-ring@web.de', '3,3 km', '', '', '1', '1', '1'),
(77, 0x323031382d30392d30392032303a35303a3339, 11, 'Nadine', 'Wellschmied', 'nwellschmied@fastviolet.de', '3,3 km', '', 'Unsere zwei Mädels werden ebenfalls laufen (7 und 9 Jahre)', '1', '1', '1'),
(79, 0x323031382d30392d30392032323a34343a3331, 11, 'Asita', 'Göttsch', 'asita.goettsch@web.de', '3,3 km', '', '', '1', '1', '1'),
(80, 0x323031382d30392d31302031383a34353a3330, 11, 'Michael', 'Lemhöfer', 'lemhoefer@web.de', '6,6 km', '', '', '1', '1', '1'),
(81, 0x323031382d30392d31302031383a34363a3439, 11, 'Johannes', 'Lemhöfer', 'lemhoefer@web.de', '6,6 km', 'Kaltenkirchener TS', '', '1', '1', '1'),
(82, 0x323031382d30392d31302032303a33323a3038, 11, 'Svenja', 'Graubaum', 'svenja_brueggen@web.de', '10 km', '', '', '1', '1', '1'),
(82, 0x323031382d30392d31302032303a35303a3230, 11, 'Tatjana', 'Brüggen', 't.brueggen@o2mail.de', '3,3 km', '', '', '1', '1', '1'),
(84, 0x323031382d30392d31302032303a35363a3537, 11, 'Doreen', 'Janke', 'janke.doreen@de.sika.com', '3,3 km', '', '2 Erwachsene, 1 Kind', '1', '1', '1'),
(82, 0x323031382d30392d31312030353a34353a3132, 11, 'Jan', 'Wunsch', 'Tex41170@googlemail.com', '10 km', '', '', '1', '1', '1'),
(86, 0x323031382d30392d31312030393a35343a3033, 11, 'Ingrid', 'Schütz', 'ingridschuetz14@gmail.com', '3,3 km', '', '', '1', '1', '1'),
(87, 0x323031382d30392d31312030393a35353a3334, 11, 'Joachim', 'Schütz', 'ingridschuetz14@gmail.com', '3,3 km', '', '', '1', '1', '1'),
(88, 0x323031382d30392d31312032313a33383a3432, 11, 'Alicia', 'Thiess', 'Thiess.Oliver@arcor.de', '820 m (Kinderlauf)', 'Klasse 1c (Zebras)', 'Die Klasse läuft geschlossen.', '1', '1', '1'),
(89, 0x323031382d30392d31312032323a32353a3338, 11, 'Lasse Christoph', 'Sabisch', 'msabisch@outlook.de', '820 m (Kinderlauf)', 'TSV Lentföhrden', '', '1', '1', '1'),
(90, 0x323031382d30392d31312032323a33313a3137, 11, 'Sonja', 'Sabisch', 'msabisch@outlook.de', '3,3 km', '', '', '1', '1', '1'),
(91, 0x323031382d30392d31312032323a33323a3334, 11, 'Phillip Leon', 'Sabisch', 'msabisch@outlook.de', '3,3 km', 'TSV Weddelbrook', '', '1', '1', '1'),
(92, 0x323031382d30392d31312032323a33343a3038, 11, 'Michael', 'Sabisch', 'msabisch@outlook.de', '6,6 km', '', '', '1', '1', '1'),
(93, 0x323031382d30392d31322031303a30373a3439, 11, 'Marco', 'Tiedeke', 'marco.tiedeke@gmail.com', '3,3 km', '', 'Gruppe: 6 Personen', '1', '1', '1'),
(94, 0x323031382d30392d31322031313a30393a3233, 11, 'Malia', 'Wagner', 'anne-marie.wagner@outlook.de', '820 m (Kinderlauf)', '', '2. Klasse', '1', '1', '1'),
(95, 0x323031382d30392d31322032323a31303a3037, 11, 'Simone', 'Rogge', 'benutzt@web.de', '3,3 km', '', 'Mario Arens 3,3 km\r\nJulian 11 Jahre Kinderlauf/3,3 km\r\nAnnabelle 7 Jahre Kinderlauf\r\n\r\n', '1', '1', '1'),
(96, 0x323031382d30392d31332030373a34353a3134, 11, 'Leni Elena', 'Bölck', 'anne-marie.wagner@outlook.de', '820 m (Kinderlauf)', '', '2. Klasse', '1', '1', '1'),
(97, 0x323031382d30392d31352030393a34383a3231, 11, 'Marcos', 'Alemany', 'marcos.carbonell.a@gmail.com', '6,6 km', '-', '', '1', '1', '1'),
(97, 0x323031382d30392d31352031303a30363a3337, 11, 'Marco', 'Möller', 'marcos.carbonell.a@gmail.com', '6,6 km', '', '', '1', '1', '1'),
(99, 0x323031382d30392d31352031303a35363a3430, 11, 'Harfrst', 'Siegrid', 'S_HH_Harfst@t-online.de', '3,3 km', '', '', '1', '1', '1'),
(100, 0x323031382d30392d31352031343a35343a3539, 11, 'vera', 'fuchs', 'vera-fuchs1974@web.de', '10 km', 'wiemersdorf', '', '1', '1', '1'),
(101, 0x323031382d30392d31352031363a33323a3135, 11, 'Stefan', 'Hensen', 'muckihensen@web.de', '3,3 km', '', '', '1', '1', '1'),
(102, 0x323031382d30392d31352031363a33343a3433, 11, 'Sabine', 'Hensen', 'muckihensen@web.de', '3,3 km', '', '', '1', '1', '1'),
(103, 0x323031382d30392d31352031383a33303a3432, 11, 'Julia', 'Reimers', 'julia_reimers@web.de', '10 km', '', 'Gruppe 2', '1', '1', '1'),
(104, 0x323031382d30392d31362032303a31383a3231, 11, 'Stine', 'Tonn', 'stine.tonn@web.de', '6,6 km', '', '', '1', '1', '1'),
(105, 0x323031382d30392d31362032303a34303a3530, 11, 'Jasmin', 'Gooden', 'jasmin.gooden@googlemail.com', '3,3 km', '', '', '1', '1', '1'),
(106, 0x323031382d30392d31362032323a34303a3436, 11, 'Britta', 'Driemeyer', 'B.Driemeyer@freenet.de', '3,3 km', '', '', '1', '1', '1'),
(107, 0x323031382d30392d31372030373a31363a3136, 11, 'Fred', 'Leifeling', 'f.leifeling@gmail.com', '3,3 km', '', '', '1', '1', '1'),
(108, 0x323031382d30392d31372030383a33353a3037, 11, 'Janina', 'Hasse', 'janina_7@hotmail.de', '3,3 km', '', '', '1', '1', '1'),
(109, 0x323031382d30392d31372030393a34353a3239, 11, 'Felix', 'Schwanke', 'kathrin.schwanke@gmx.de', '820 m (Kinderlauf)', '', 'Grundschule Klasse 4', '1', '1', '1'),
(110, 0x323031382d30392d31372030393a34363a3232, 11, 'Paula', 'Schwanke', 'kathrin.schwanke@gmx.de', '820 m (Kinderlauf)', '', 'Grundschule Klasse 1', '1', '1', '1'),
(111, 0x323031382d30392d31372031343a34393a3436, 11, 'Matthias', 'Bünger', 'mat.buenger@web.de', '6,6 km', '', '', '1', '1', '1'),
(112, 0x323031382d30392d31372031373a34303a3539, 11, 'Jaimy', 'Paulsen', 'ch.pau@web.de', '3,3 km', '', '', '1', '1', '1'),
(113, 0x323031382d30392d31372031373a34313a3530, 11, 'Nick', 'Paulsen', 'ch.pau@web.de', '3,3 km', '', '', '1', '1', '1'),
(114, 0x323031382d30392d31382031343a34363a3436, 11, 'Torsten', 'Eggers', 'toreggers@gmail.com', '3,3 km', 'Lentföhrden', 'Gruppe 2', '1', '1', '1'),
(115, 0x323031382d30392d31382031373a35393a3335, 11, 'Heinrich', 'Leifeling', 'f.leifeling@gmail.com', '3,3 km', '', '', '1', '1', '1'),
(116, 0x323031382d30392d31382031383a32343a3235, 11, 'Daniela', 'Röpke', 'Daniela.Roepke@web.de', '3,3 km', '', '', '1', '1', '1'),
(117, 0x323031382d30392d31382031393a35303a3136, 11, 'Anke', 'NEUMANN', 'anke.nn.neumann@web.de', '3,3 km', '', '', '1', '1', '1'),
(117, 0x323031382d30392d31382031393a35313a3437, 11, 'Michael', 'Neumann', 'familie.nn.neumann@web.de', '6,6 km', '', '', '1', '1', '1'),
(119, 0x323031382d30392d31382032303a30323a3033, 11, 'Rene', 'Knipping', 'knipser319@gmx.de', '6,6 km', 'Knipping Kälte &amp; Klimatechnik Gmbh', '', '1', '1', '1'),
(120, 0x323031382d30392d31382032303a33393a3036, 11, 'Mia', 'Larberg', 'mr.larberg@t-online.de', '820 m (Kinderlauf)', '', '', '1', '1', '1'),
(120, 0x323031382d30392d31382032303a33393a3433, 11, 'Maren', 'Larberg', 'mr.larberg@t-online.de', '3,3 km', '', '', '1', '1', '1'),
(122, 0x323031382d30392d31382032303a34343a3037, 11, 'Mia', 'Larberg', 'mr.larberg@t-online.de', '3,3 km', '', '\r\nBitte die Anmeldung für den Kinderlauf für Mia Larberg stornieren. Anmeldung erfolgte irrtümlich', '1', '1', '1'),
(123, 0x323031382d30392d31382032323a30363a3532, 11, 'Ulrike', 'Möller', 'umoeller@freenet.de', '3,3 km', '', '', '1', '1', '1'),
(124, 0x323031382d30392d31382032323a31303a3530, 11, 'Erik', 'Möller', 'umoeller@freenet.de', '3,3 km', '', '', '1', '1', '1'),
(125, 0x323031382d30392d31382032323a31313a3332, 11, 'Silja', 'Möller', 'umoeller@freenet.de', '3,3 km', '', '', '1', '1', '1'),
(126, 0x323031382d30392d31382032323a31323a3035, 11, 'Finn', 'Möller', 'umoeller@freenet.de', '3,3 km', '', '', '1', '1', '1'),
(127, 0x323031382d30392d31392031303a34323a3032, 11, 'Femke', 'Christiansen-Schmidt', 'femke85@gmx.de', '3,3 km', '', 'Gruppe (2)', '1', '1', '1'),
(128, 0x323031382d30392d31392031383a32393a3032, 11, 'Fin-Luca', 'Wegner', 'wegnersaliha@yahoo.de', '820 m (Kinderlauf)', '', '', '1', '1', '1'),
(129, 0x323031382d30392d31392032303a31353a3236, 11, 'Bille', 'Thies', 'billesun@web.de', '3,3 km', 'TSV Nützen', '', '1', '1', '1'),
(130, 0x323031382d30392d32302030383a32393a3235, 11, 'Mark', 'Dräger', 'm-draeger@eherls-partner.de', '6,6 km', '', '', '1', '1', '1'),
(131, 0x323031382d30392d32302031333a33353a3534, 11, 'Finn', 'Rehbein', 'darkhondadriver@gmail.com', '820 m (Kinderlauf)', 'SG Weddelbrook/ Nützen', '', '1', '1', '1'),
(132, 0x323031382d30392d32302031353a33383a3335, 11, 'Evelyn', 'Vanhöf', 'evelyn.vanhoef@googlemail.com', '3,3 km', '', '', '1', '1', '1'),
(133, 0x323031382d30392d32312031343a33323a3535, 11, 'Anja', 'Tölle', 'fam.toelle@gmx.net', '3,3 km', '', 'Gruppe—3 Erwachsene', '1', '1', '1'),
(134, 0x323031382d30392d32312032303a30333a3137, 11, 'Johanna', 'Ranuschewitz', 'johanna@ranuschewitz.de', '6,6 km', '', 'Gruppe, 2 Personen', '1', '1', '1'),
(135, 0x323031382d30392d32322030393a31303a3533, 11, 'Finja', 'Keizl', 'marc@keizl.de', '820 m (Kinderlauf)', '', '', '1', '1', '1'),
(135, 0x323031382d30392d32322030393a31313a3437, 11, 'Peetje', 'Keizl', 'marc@keizl.de', '820 m (Kinderlauf)', '', '', '1', '1', '1'),
(137, 0x323031382d30392d32322031363a31333a3333, 11, 'Maik', 'Rogge', 'maik.rogge@web.de', '3,3 km', '', '', '1', '1', '1'),
(138, 0x323031382d30392d32322031363a32343a3436, 11, 'Toni', 'Rogge', 'maik.rogge@web.de', '820 m (Kinderlauf)', '', '', '1', '1', '1'),
(139, 0x323031382d30392d32322031373a30353a3136, 11, 'Finn', 'Bartels', 'finnbartels06@gmail.com', '3,3 km', 'TSV Lentföhrden', '', '1', '1', '1'),
(140, 0x323031382d30392d32322031393a34313a3238, 11, 'Claudia', 'Söhrnsen', 'claudia3st@yahoo.de', '3,3 km', '', '', '1', '1', '1'),
(141, 0x323031382d30392d32322031393a34343a3338, 11, 'Jesko', 'Leon', 'claudia3st@yahoo.de', '3,3 km', '', '', '1', '1', '1'),
(142, 0x323031382d30392d32322032333a30303a3037, 11, 'Doreen', 'Neumeister', 'Doreen.neumeister@gmx.net', '3,3 km', 'Lentföhrden', 'Gruppe 3 Personen', '1', '1', '1'),
(143, 0x323031382d30392d32332030393a33373a3330, 11, 'Michael', 'Malewski', 'm.malewski@web.de', '3,3 km', 'Team Antonia Boys in Green', '', '1', '1', '1'),
(143, 0x323031382d30392d32332030393a33383a3232, 11, 'Christine', 'Malewski', 'm.m.malewski@web.de', '3,3 km', 'Team Antonia Boys in Green', '', '1', '1', '1');
/*!40000 ALTER TABLE `wp_laufanmeldungen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Backup routines for database 'db212304x2747338'
--

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Backup completed on 2018-10-05 03:44:22
